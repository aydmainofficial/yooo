# Fuyuumi <img src="https://s.put.re/pgh732Cd.png" width="45" />
A GUI being made for discord-spam-bots, very slowly.

>For info/progress follow https://twitter.com/merubokkusu
![](https://s.put.re/zzkc8idb.png)

![](http://giphygifs.s3.amazonaws.com/media/9qRIkXrwMa6go/giphy.gif)
